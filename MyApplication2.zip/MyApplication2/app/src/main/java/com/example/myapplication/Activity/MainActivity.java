package com.example.myapplication.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.Adapter.CommonRecycleViewAdapter;
import com.example.myapplication.Model.Todo;
import com.example.myapplication.R;
import com.example.myapplication.Utility.ApiURL;
import com.example.myapplication.Utility.WebService;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements WebService.iWebService, CommonRecycleViewAdapter.ReturnView {
    RecyclerView listQuery;
    private CommonRecycleViewAdapter recycleAdapter;
    private ArrayList<Todo> listTodos = new ArrayList<>();
    private int currentPage = 1; // Track current page for pagination
    private boolean isLoading = false; // Track if data is being loaded

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listQuery = (RecyclerView) findViewById(R.id.my_recycle_view);
        recycleAdapter = new CommonRecycleViewAdapter(listTodos, MainActivity.this, R.layout.card_todo, this, 1);
        listQuery.setLayoutManager(new LinearLayoutManager(this));
        listQuery.setHasFixedSize(true);
        listQuery.setAdapter(recycleAdapter);
        listQuery.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
                int visibleItemCount = layoutManager.getChildCount();
                int totalItemCount = layoutManager.getItemCount();
                int firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition();
                if (!isLoading) {
                    if ((visibleItemCount + firstVisibleItemPosition) >= totalItemCount
                            && firstVisibleItemPosition >= 0) {
                        // End of list reached, load more data
                        currentPage++;
                        apiCalling(currentPage);
                    }
                }
            }
        });
        apiCalling(currentPage);
    }

    private void apiCalling(int page) {
        isLoading = true; // Set loading state
        String apiUrl = ApiURL.APP_BASE_URL + "todos?_page=" + page + "&_limit=10"; // Adjust as per your API pagination structure
        WebService getDataUsingWService = new WebService(MainActivity.this, apiUrl, 1, "", true, this);
        getDataUsingWService.execute();
    }


    @Override
    public void webServiceResponse(JSONArray response, int serviceCounter) throws Exception {
        try {
            for (int i = 0; i < response.length(); i++) {
                JSONObject jsonObject = response.getJSONObject(i);
                Todo todo = new Todo(jsonObject.getInt("userId"),jsonObject.getInt("id"),jsonObject.getString("title"),jsonObject.getBoolean("completed"));
                listTodos.add(todo);
            }
            recycleAdapter.notifyDataSetChanged();
        } catch (JSONException e) {
            Toast.makeText(this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        isLoading = false; // Reset loading state after data is loaded

    }

    @Override
    public void getAdapterView(View view, List objects, int position, int from) {
        final Todo todo = listTodos.get(position);
        TextView textTitle = view.findViewById(R.id.textTitle);
        TextView textId = view.findViewById(R.id.textId);
        TextView textCompleted = view.findViewById(R.id.textCompleted);
        textId.setText("Id :"+todo.getId());
        textTitle.setText(todo.getTitle());
        textCompleted.setText("Completed: " + (todo.isCompleted() ? "Yes" : "No"));
        textCompleted.setTextColor(todo.isCompleted() ? Color.GREEN : Color.RED);


    }
}