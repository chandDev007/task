package com.example.myapplication.Utility;

public class ApiURL {

    public final static String APP_BASE_URL = "https://jsonplaceholder.typicode.com/";



}
