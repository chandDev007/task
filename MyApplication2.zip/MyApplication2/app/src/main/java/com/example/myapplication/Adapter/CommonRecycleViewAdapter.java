package com.example.myapplication.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CommonRecycleViewAdapter extends RecyclerView.Adapter<CommonRecycleViewAdapter.ProfileHolder> {

    private List list;
    private Context context;
    private int layout;
    ReturnView returnView;
    int from;

    public interface ReturnView {
        void getAdapterView(View view, List objects, int position, int from);
    }

    public CommonRecycleViewAdapter(List list1, Context context, int layout, ReturnView returnView, int from) {
        this.list = list1;
        this.context = context;
        this.layout = layout;
        this.returnView = returnView;
        this.from = from;
    }

    public void notifyData(List list1) {
        try {
            this.list = list1;
            notifyDataSetChanged();
        } catch (Exception e) {
        }
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public void onBindViewHolder(ProfileHolder rideHistoryViewHolder, final int i) {
        returnView.getAdapterView(rideHistoryViewHolder.v, list, i, from);
    }

    @Override
    public ProfileHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.
                from(viewGroup.getContext()).
                inflate(layout, viewGroup, false);
        return new ProfileHolder(itemView);
    }

    public static class ProfileHolder extends RecyclerView.ViewHolder {
        View v;

        public ProfileHolder(View v) {
            super(v);
            this.v = v;
        }
    }
}
