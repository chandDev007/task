package com.example.myapplication.Utility;

import static android.content.Context.WIFI_SERVICE;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Process;
import android.provider.Settings;
import android.text.format.Formatter;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

public class WebService {

    private Activity activity;
    private String params;
    private String webServiceURL;
    private iWebService WebService;
    Context context;
    private int serviceCounter;
    private boolean isShow;
    boolean isShowNoNetwork = true;
    ProgressDialog progressDialog;
    public interface iWebService {
        void webServiceResponse(JSONArray jsonArray, int serviceCounter) throws Exception;
    }

    public WebService(boolean isShowNoNetwork, Activity activity, String webServiceURL, int serviceCounter, String params, boolean isShow, iWebService WebService) {
        this.isShowNoNetwork = isShowNoNetwork;
        this.activity = activity;
        this.params = params;
        this.webServiceURL = webServiceURL;
        this.serviceCounter = serviceCounter;
        this.isShow = isShow;
        this.WebService = WebService;
    }

    public WebService(Activity activity, String webServiceURL, int serviceCounter, String params, boolean isShow, iWebService WebService) {
        this.isShowNoNetwork = true;
        this.activity = activity;
        this.params = params;
        this.webServiceURL = webServiceURL;
        this.serviceCounter = serviceCounter;
        this.isShow = isShow;
        this.WebService = WebService;
    }

    public void execute() {
        if (isShow) {
            try {
                progressDialog = new ProgressDialog(activity);
                progressDialog.setMessage("Loading...");
                progressDialog.setCanceledOnTouchOutside(false);
                progressDialog.setCancelable(false);
                progressDialog.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            RequestQueue requestQueue = Volley.newRequestQueue(activity);
            Log.e(">>>>params", params);
            Log.e(">>>>webServiceURL", webServiceURL);
            StringRequest stringRequest = new StringRequest(Request.Method.GET,
               webServiceURL, new Response.Listener<String>() {

                    @Override
                public void onResponse(String response1) {
                        Log.e(">>>>response1", response1);

                        try {
                       // JSONObject jsonObject = new JSONObject(response1);
                            JSONArray jsonArray= new JSONArray(response1);
                        if (jsonArray != null) {
                            WebService.webServiceResponse(jsonArray, serviceCounter);
                        }

                        progressDialog_dismiss();
                    } catch (Exception e) {
                        e.printStackTrace();
                        progressDialog_dismiss();
                        
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError volleyError) {
                    try {
                        progressDialog_dismiss();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    String message = null;
                    if (volleyError instanceof NetworkError) {
                        message = "Cannot connect to Internet...Please check your connection!";
                        Log.e(">>>>>>>", "NetworkError");
                         } else if (volleyError instanceof ServerError) {
                        message = "The server could not be found. Please try again after some time!!";
                    } else if (volleyError instanceof AuthFailureError) {
                        message = "Cannot connect to Internet...Please check your connection!";
                        Log.e(">>>>>>>", "AuthFailureError");
                    } else if (volleyError instanceof ParseError) {
                        message = "Parsing error! Please try again after some time!!";
                    } else if (volleyError instanceof NoConnectionError) {
                        message = "Cannot connect to Internet...Please check your connection!";
                    } else if (volleyError instanceof TimeoutError) {
                        message = "Connection TimeOut! Please check your internet connection.";
                        Log.e(">>>>>>>", "TimeoutError");
                        if (isShowNoNetwork) ;
                    }
                    Log.e(">>>>volleyError", volleyError.toString());

                }
            }) {

                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                public byte[] getBody() throws AuthFailureError {
                    try {
                        return params == null ? null : params.getBytes("utf-8");
                    } catch (UnsupportedEncodingException uee) {
                        Log.e(">>>>volleyError", uee.toString());

                        return null;
                    }
                }

                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap headers = new HashMap();
                    headers.put("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                    Log.e(">>>> Headers ", headers.toString());
                    return headers;
                }
            };

            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    60000,
                    0,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            requestQueue.add(stringRequest);
        } catch (Exception e) {
            progressDialog_dismiss();
        Log.e(".>>>>>>>>>>>", e.toString());
        }
    }

    void progressDialog_dismiss ()
    {
        if (isShow & progressDialog != null) {
            progressDialog.hide();
            progressDialog.dismiss();
        }

    }


}
